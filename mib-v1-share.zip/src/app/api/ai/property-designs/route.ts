import { NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

export async function GET(
  request: Request
) {
  try {
    const { searchParams } =
      new URL(request.url);

    const propertyId =
      searchParams.get("property_id");

    if (!propertyId) {
      return NextResponse.json(
        {
          success: false,
          error:
            "property_id is required.",
        },
        {
          status: 400,
        }
      );
    }

    const { data, error } =
      await supabase
        .from("ai_designs")
        .select("*")
        .eq(
          "property_id",
          propertyId
        )
        .order(
          "created_at",
          {
            ascending: false,
          }
        );

    if (error) {
      console.error(
        "AI DESIGNS QUERY ERROR:",
        error
      );

      return NextResponse.json(
        {
          success: false,
          error:
            error.message,
        },
        {
          status: 500,
        }
      );
    }

    return NextResponse.json({
      success: true,
      designs: data || [],
    });

  } catch (error: any) {
    console.error(
      "AI DESIGNS API ERROR:",
      error
    );

    return NextResponse.json(
      {
        success: false,
        error:
          error?.message ||
          "Failed to load AI designs.",
      },
      {
        status: 500,
      }
    );
  }
}

/*
|--------------------------------------------------------------------------
| DELETE — DELETE AI DESIGN
|--------------------------------------------------------------------------
*/

export async function DELETE(
  request: Request
) {
  try {
    const body =
      await request.json();

    const designId =
      body?.id;

    if (!designId) {
      return NextResponse.json(
        {
          success: false,
          error:
            "Design ID is required.",
        },
        {
          status: 400,
        }
      );
    }

    /*
    |--------------------------------------------------------------------------
    | GET DESIGN
    |--------------------------------------------------------------------------
    */

    const { data: design, error: findError } =
      await supabase
        .from("ai_designs")
        .select("*")
        .eq("id", designId)
        .single();

    if (findError || !design) {
      return NextResponse.json(
        {
          success: false,
          error:
            findError?.message ||
            "AI design not found.",
        },
        {
          status: 404,
        }
      );
    }

    const marker =
  "/storage/v1/object/public/ai-designs/";

const markerIndex =
  design.image_url.indexOf(marker);

if (markerIndex !== -1) {
  const storagePath =
    decodeURIComponent(
      design.image_url.substring(
        markerIndex + marker.length
      )
    );

  const { error: storageError } =
    await supabase.storage
      .from("ai-designs")
      .remove([storagePath]);

  if (storageError) {
    console.error(
      "AI DESIGN STORAGE DELETE ERROR:",
      storageError
    );

    return NextResponse.json(
      {
        success: false,
        error: storageError.message,
      },
      { status: 500 }
    );
  }
}

    /*
    |--------------------------------------------------------------------------
    | DELETE DATABASE RECORD
    |--------------------------------------------------------------------------
    */

    const { error: deleteError } =
      await supabase
        .from("ai_designs")
        .delete()
        .eq("id", designId);

    if (deleteError) {
      console.error(
        "AI DESIGN DATABASE DELETE ERROR:",
        deleteError
      );

      return NextResponse.json(
        {
          success: false,
          error:
            deleteError.message,
        },
        {
          status: 500,
        }
      );
    }

    /*
    |--------------------------------------------------------------------------
    | RETURN SUCCESS
    |--------------------------------------------------------------------------
    */

    return NextResponse.json({
      success: true,
    });

  } catch (error: any) {
    console.error(
      "AI DESIGN DELETE ERROR:",
      error
    );

    return NextResponse.json(
      {
        success: false,
        error:
          error?.message ||
          "Failed to delete AI design.",
      },
      {
        status: 500,
      }
    );
  }
}