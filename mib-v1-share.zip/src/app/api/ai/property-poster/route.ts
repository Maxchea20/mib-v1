import { NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";

const supabaseAdmin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

/*
|--------------------------------------------------------------------------
| GET — LOAD AI DESIGNS
|--------------------------------------------------------------------------
*/

export async function GET(
  request: Request
) {
  try {
    const { searchParams } =
      new URL(request.url);

    const propertyId =
      searchParams.get("property_id");

    if (!propertyId) {
      return NextResponse.json(
        {
          success: false,
          error:
            "property_id is required.",
        },
        {
          status: 400,
        }
      );
    }

    const {
      data,
      error,
    } =
      await supabaseAdmin
        .from("ai_designs")
        .select("*")
        .eq(
          "property_id",
          propertyId
        )
        .order(
          "created_at",
          {
            ascending: false,
          }
        );

    if (error) {
      console.error(
        "AI DESIGNS QUERY ERROR:",
        error
      );

      return NextResponse.json(
        {
          success: false,
          error:
            error.message,
        },
        {
          status: 500,
        }
      );
    }

    return NextResponse.json({
      success: true,
      designs: data || [],
    });

  } catch (error: any) {
    console.error(
      "AI DESIGNS GET ERROR:",
      error
    );

    return NextResponse.json(
      {
        success: false,
        error:
          error?.message ||
          "Failed to load AI designs.",
      },
      {
        status: 500,
      }
    );
  }
}

/*
|--------------------------------------------------------------------------
| DELETE — REMOVE AI DESIGN
|--------------------------------------------------------------------------
*/

export async function DELETE(
  request: Request
) {
  try {
    const body =
      await request.json();

    const designId =
      body?.id;

    if (!designId) {
      return NextResponse.json(
        {
          success: false,
          error:
            "Design ID is required.",
        },
        {
          status: 400,
        }
      );
    }

    /*
    |--------------------------------------------------------------------------
    | GET DESIGN RECORD
    |--------------------------------------------------------------------------
    */

    const {
      data: design,
      error: findError,
    } =
      await supabaseAdmin
        .from("ai_designs")
        .select(
          "id, image_url"
        )
        .eq(
          "id",
          designId
        )
        .single();

    if (findError) {
      console.error(
        "AI DESIGN FIND ERROR:",
        findError
      );

      return NextResponse.json(
        {
          success: false,
          error:
            findError.message,
        },
        {
          status: 404,
        }
      );
    }

    /*
    |--------------------------------------------------------------------------
    | EXTRACT STORAGE PATH
    |--------------------------------------------------------------------------
    */

    let storagePath = "";

    try {
      const url =
        new URL(
          design.image_url
        );

      const marker =
        "/storage/v1/object/public/ai-designs/";

      const markerIndex =
        url.pathname.indexOf(
          marker
        );

      if (
        markerIndex !== -1
      ) {
        storagePath =
          decodeURIComponent(
            url.pathname.substring(
              markerIndex +
                marker.length
            )
          );
      }

    } catch (error) {
      console.error(
        "AI DESIGN URL PARSE ERROR:",
        error
      );
    }

    /*
    |--------------------------------------------------------------------------
    | DELETE STORAGE FILE
    |--------------------------------------------------------------------------
    */

    if (storagePath) {
      const {
        error:
          storageError,
      } =
        await supabaseAdmin
          .storage
          .from(
            "ai-designs"
          )
          .remove([
            storagePath,
          ]);

      if (storageError) {
        console.error(
          "AI DESIGN STORAGE DELETE ERROR:",
          storageError
        );

        return NextResponse.json(
          {
            success: false,
            error:
              `Failed to delete poster file: ${storageError.message}`,
          },
          {
            status: 500,
          }
        );
      }

      console.log(
        "AI DESIGN STORAGE DELETED:",
        storagePath
      );
    }

    /*
    |--------------------------------------------------------------------------
    | DELETE DATABASE RECORD
    |--------------------------------------------------------------------------
    */

    const {
      error:
        deleteError,
    } =
      await supabaseAdmin
        .from("ai_designs")
        .delete()
        .eq(
          "id",
          designId
        );

    if (deleteError) {
      console.error(
        "AI DESIGN DATABASE DELETE ERROR:",
        deleteError
      );

      return NextResponse.json(
        {
          success: false,
          error:
            deleteError.message,
        },
        {
          status: 500,
        }
      );
    }

    console.log(
      "AI DESIGN DELETED:",
      designId
    );

    return NextResponse.json({
      success: true,
    });

  } catch (error: any) {
    console.error(
      "AI DESIGN DELETE ERROR:",
      error
    );

    return NextResponse.json(
      {
        success: false,
        error:
          error?.message ||
          "Failed to delete AI design.",
      },
      {
        status: 500,
      }
    );
  }
}